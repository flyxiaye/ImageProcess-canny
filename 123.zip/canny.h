#ifndef CANNY_H
#define CANNY_H
void CannyEage(void);
void ShowEage(unsigned char *p);
#endif // !CANNY_H
