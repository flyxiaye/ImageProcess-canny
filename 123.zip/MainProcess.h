#ifndef MainProcess_H
#define MainProcess_H
void MainFill(void);
void GetML(void);
int StopCar(void);
void SelectFirstLine(void);
int JudgeOutBroken(void);
#endif // !MainProcess_H
#pragma once
