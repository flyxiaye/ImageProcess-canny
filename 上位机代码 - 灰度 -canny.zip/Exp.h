#ifndef Exp_H
#define Exp_H
void Exp(void);
#endif // !Exp_H
#pragma once
