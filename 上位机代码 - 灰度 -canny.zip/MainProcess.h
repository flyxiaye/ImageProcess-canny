#ifndef MainProcess_H
#define MainProcess_H
void MainFill(void);
void GetML(void);
void SelectFirstLine(void);
int JudgeOutBroken(void);
int IsStopLine(int line, int left, int right);
#endif // !MainProcess_H
#pragma once
