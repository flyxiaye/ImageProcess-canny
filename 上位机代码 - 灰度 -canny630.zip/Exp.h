#ifndef Exp_H
#define Exp_H
void Exp(void);
unsigned char IndJudgeCircle(unsigned char type);
void FindLineNormal_1(int Fill);
void FindLineLost_1(void);
unsigned char Dist_ClearIslandSeven(void);
#endif // !Exp_H
#pragma once
